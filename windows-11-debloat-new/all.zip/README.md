# Windows 11 Debloater 🚀

This script will be re-designed. 

If you have any issues then [join my Discord Server.](https://discord.gg/JtMvqaNR5V) (Dead lol)

# How to use?

To start this script, run ``Launch.bat`` as Administrator!

You can find source code from ``src\main.ps1`` or [here](https://github.com/teeotsa/windows-11-debloat/blob/new/src/main.ps1).

If you have anything else, please check out our [wiki page!](https://github.com/teeotsa/windows-11-debloat/wiki/Launching-the-script.)

# Issues starting up

Issues might occur when trying to start my script, so I'll list some solutions.

* **Try to disable Windows Defender or add exclusion.**
* **Run script directly from PowerShell with Admin privileges**

# Known issues

* No Lock Screen Customization | [Here's the fix](https://github.com/teeotsa/windows-11-debloat/wiki/Wiki-Page-(-NO-IDEAS-MOMENT-)#known-issues)
